Please do not submit any Pull Requests here. It will be automatically closed.

You should submit it here: https://github.com/web-token/jwt-framework/pulls
